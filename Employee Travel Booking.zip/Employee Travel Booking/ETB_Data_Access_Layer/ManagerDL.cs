﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ETB_Entity_Layer;
using System.Data;
using System.Data.SqlClient;

namespace ETB_Data_Access_Layer
{
    public class ManagerDL
    {
        SqlConnection conn = new SqlConnection(@"data source=LAPTOP-11GTHP3H\SQLEXPRESS ;initial catalog=Sprint_1;integrated security=true");

        public int Assign(Manager manager)
        {
            conn.Open();
            string query = "update employee set Mid='"
                + manager.Mid
                + "', designation='" + manager.Designation
                + "' where Empid=" + manager.EmpId;
            SqlCommand cmd = new SqlCommand(query, conn);
            int rowsAffected = cmd.ExecuteNonQuery();
            conn.Close();
            return rowsAffected;
        }

        public int Change(Manager manager)
        {
            conn.Open();
            string query = "update employee set Mid='"
                + manager.Mid
                + "' where Empid=" + manager.EmpId;
            SqlCommand cmd = new SqlCommand(query, conn);
            int rowsAffected = cmd.ExecuteNonQuery();
            conn.Close();
            return rowsAffected;
        }

        public SqlDataReader Search(Manager manager)
        {
            SqlCommand cmd = new SqlCommand("select * from employee where Empid =" + manager.EmpId, conn);
            conn.Open();
            SqlDataReader objDR = cmd.ExecuteReader();
            objDR.Read();
            return objDR;
        }
    }
}
