﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ETB_Entity_Layer;

namespace ETB_Data_Access_Layer
{
    public class BookDL
    {
        SqlConnection conn = new SqlConnection(@"data source=LAPTOP-11GTHP3H\SQLEXPRESS ;initial catalog=Sprint_1;integrated security=true");

        public int BookTicket(Book book)
        {
            try
            {
                conn.Open();
                string query = "insert into TravelIntenary(Bid, Tid, DateOfJourny, Cost) values('" + book.Bid + "','" + book.Tid + "', '" + DateTime.Parse(book.DateOfJourny).ToString("MM-dd-yyyy") + "'," + book.Cost + ")";

                SqlCommand cmd = new SqlCommand(query, conn);
                int rowsAffected = cmd.ExecuteNonQuery();
                conn.Close();
                return rowsAffected;
            }
            catch(SqlException sql)
            {
                throw sql;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
