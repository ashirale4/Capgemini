﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using ETB_Entity_Layer;

namespace ETB_Data_Access_Layer
{
    public class EmployeeDL
    {
        SqlConnection conn = new SqlConnection(@"data source=LAPTOP-11GTHP3H\SQLEXPRESS ;initial catalog=Sprint_1;integrated security=true");

        public int Insert(Employee emp)
        {
            conn.Open();
            string query = "insert into Employee(EmpId, EName, Department, Designation, City, Password) values(" + emp.EmpId + ", '" + emp.Name + "','" + emp.Department + "','" + emp.Designation + "','" + emp.City + "','" + emp.Password + "')";

            SqlCommand cmd = new SqlCommand(query, conn);
            int rowsAffected = cmd.ExecuteNonQuery();
            conn.Close();
            return rowsAffected;
        }
        public int Delete(Employee emp)
        {
            conn.Open();
            string query = "Delete from Employee where EmpId=" + emp.EmpId;
            SqlCommand cmd = new SqlCommand(query,conn);
            int rowsAffected = cmd.ExecuteNonQuery();
            conn.Close ();
            return rowsAffected;
        }
        public int Update(Employee emp)
        {
            conn.Open();
            SqlCommand objCom = new SqlCommand("update employee set EName='"
                + emp.Name
                + "', Department='" + emp.Department
                + "', Designation='" + emp.Designation
                + "', City='" + emp.City
                + "', Password='" + emp.Password
                + "' where Empid=" + emp.EmpId, conn);

            int rowsAffected = objCom.ExecuteNonQuery();
            conn.Close();
            return rowsAffected;
        }
        public SqlDataReader ListEmployee()
        {
            conn.Open();
            string query = "select * from employee";
            SqlCommand cmd = new SqlCommand (query, conn);
            SqlDataReader reader = cmd.ExecuteReader();
            conn.Close();
            return reader;
        }

    }
}
