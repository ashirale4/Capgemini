﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using ETB_Entity_Layer;

namespace ETB_Data_Access_Layer
{
    public class TicketDL
    {
        SqlConnection conn = new SqlConnection(@"data source=LAPTOP-11GTHP3H\SQLEXPRESS ;initial catalog=Sprint_1;integrated security=true");

        public int Insert(Ticket ticket)
        {
            conn.Open();
            string query = "insert into Ticket(Tid, Empid, Source, Destination, FlightDate, Seats) values('" + ticket.Tid + "',"+ticket.EmpId+", '" + ticket.Source + "','" + ticket.Destination + "','" + DateTime.Parse(ticket.FlightDate).ToString("MM-dd-yyyy") + "','" + ticket.Seats + "')";

            SqlCommand cmd = new SqlCommand(query, conn);
            int rowsAffected = cmd.ExecuteNonQuery();
            conn.Close();
            return rowsAffected;
        }

        public int Reject(Ticket ticket)
        {
            conn.Open();
            string query = "update Ticket set Status='"
                + ticket.Status
                + "' where Empid=" + ticket.EmpId;

            SqlCommand cmd = new SqlCommand(query, conn);
            int rowsAffected = cmd.ExecuteNonQuery();
            conn.Close();
            return rowsAffected;
        }

        public int Delete(Ticket ticket)
        {
            conn.Open();
            string query = "Delete from Ticket where Empid=" + ticket.EmpId;

            SqlCommand cmd = new SqlCommand(query, conn);
            int rowsAffected = cmd.ExecuteNonQuery();
            conn.Close();
            return rowsAffected;
        }
    }
}
