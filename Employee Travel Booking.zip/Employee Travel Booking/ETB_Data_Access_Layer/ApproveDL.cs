﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ETB_Entity_Layer;

namespace ETB_Data_Access_Layer
{
    public class ApproveDL
    {
        SqlConnection conn = new SqlConnection(@"data source=LAPTOP-11GTHP3H\SQLEXPRESS ;initial catalog=Sprint_1;integrated security=true");

        public int Approve(Approve approve)
        {
            conn.Open();
            string query = "insert into Approve(Tid, empid, Source, Destination, FlightDate, Seats) select Tid, empid, Source, Destination, FlightDate, Seats From Ticket where Empid=" + approve.EmpId;
            SqlCommand cmd = new SqlCommand(query, conn);
            int rowsAffected = cmd.ExecuteNonQuery();
            conn.Close();
            return rowsAffected;
        }

        public int Status(Approve approve)
        {
            conn.Open();
            string query = "update Approve set Status='"
                + approve.Status
                + "' where Tid='" + approve.Tid + "' " ;
            SqlCommand cmd = new SqlCommand(query, conn);
            int rowsAffected = cmd.ExecuteNonQuery();
            conn.Close();
            return rowsAffected;
        }
    }
}
