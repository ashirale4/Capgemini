﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ETB_Entity_Layer;

namespace ETB_Data_Access_Layer
{
    public class TravelAgentDL
    {
        SqlConnection conn = new SqlConnection(@"data source=LAPTOP-11GTHP3H\SQLEXPRESS;initial catalog=Sprint_1;integrated security=true");

        public int Insert(TravelAgent agent)
        {
            conn.Open();
            string query = "insert into TravelAgent(Agentid, AgentName, C_No, Password) values('" + agent.AgentId + "', '" + agent.AgentName + "','" + agent.Phone + "','" + agent.Password + "')";

            SqlCommand cmd = new SqlCommand(query, conn);
            int rowsAffected = cmd.ExecuteNonQuery();
            conn.Close();
            return rowsAffected;
        }

        public int Delete(TravelAgent agent)
        {
            conn.Open();
            string query = "Delete from TravelAgent where Agentid=" + agent.AgentId;
            SqlCommand cmd = new SqlCommand(query, conn);
            int rowsAffected = cmd.ExecuteNonQuery();
            conn.Close();
            return rowsAffected;
        }

        public int Update(TravelAgent agent)
        {
            conn.Open();
            string query = "update TravelAgent set C_No="+agent.Phone+", Password='"
                + agent.Password
                + "' where AgentName=" + agent.AgentName;
            SqlCommand cmd = new SqlCommand(query, conn);
            int rowsAffected = cmd.ExecuteNonQuery();
            conn.Close();
            return rowsAffected;
        }
    }
}
