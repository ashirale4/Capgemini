﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ETB_Entity_Layer
{
    public class Manager
    {
        public int EmpId { get; set; }
        public int Mid { get; set; }
        public string Name { get; set; }
        public string Designation { get; set; }
    }
}
