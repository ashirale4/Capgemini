﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ETB_Entity_Layer
{
    public class Book
    {
        public string Bid { get; set; }
        public string Tid { get; set; }
        public string DateOfJourny { get; set; }
        public double Cost { get; set; }
    }
}
