﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ETB_Entity_Layer;
using ETB_Data_Access_Layer;

namespace ETB_Business_Layer
{
    public class ApproveBL
    {
        public bool ApproveEmployee(Approve approve)
        {
            try
            {
                //ValidateEmployeeInput(emp);
                ApproveDL approveDL = new ApproveDL();
                approveDL.Approve(approve);
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool TicketStatus(Approve approve)
        {
            try
            {
                //ValidateEmployeeInput(emp);
                ApproveDL approveDL = new ApproveDL();
                approveDL.Status(approve);
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}
