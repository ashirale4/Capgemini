﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ETB_Entity_Layer;
using ETB_Data_Access_Layer;

namespace ETB_Business_Layer
{
    public class TicketBL
    {
        public bool AddTicket(Ticket ticket)
        {
            try
            {
                //ValidateEmployeeInput(ticket);
                TicketDL ticketDL = new TicketDL();
                //string empid = GenerateEmployeeID();
                //emp.EmpId = empid;
                ticketDL.Insert(ticket);
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool RejectTicket(Ticket ticket)
        {
            try
            {
                //ValidateEmployeeInput(ticket);
                TicketDL ticketDL = new TicketDL();
                //string empid = GenerateEmployeeID();
                //emp.EmpId = empid;
                ticketDL.Reject(ticket);
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool CancelTicket(Ticket ticket)
        {
            try
            {
                //ValidateEmployeeInput(ticket);
                TicketDL ticketDL = new TicketDL();
                //string empid = GenerateEmployeeID();
                //emp.EmpId = empid;
                ticketDL.Delete(ticket);
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private string GenerateEmployeeID()
        {

            string empid;

            string lastGeneratedAID = "T001";
            int id = Convert.ToInt32(lastGeneratedAID.Substring(1));
            id++;
            if (id < 10)
                empid = "T00" + id;
            else if (id < 100)
                empid = "T0" + id;
            else
                empid = "T" + id;

            return empid;
        }

        //public bool ValidateEmployeeInput(Ticket ticket)
        //{
        //    try
        //    {
        //        if (CheckName(emp.Name) && CheckCity(emp.City) && CheckPassword(emp.Password))
        //            return true;

        //    }
        //    catch (InvalidNameException ine)
        //    {
        //        throw ine;
        //    }
        //    catch (InvalidPasswordException ine)
        //    {
        //        throw ine;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    return false;
        //}

        //public bool CheckName(string name)
        //{
        //    if (Regex.IsMatch(name, "^[A-Za-z]{3,}$"))
        //        return true;
        //    throw new InvalidNameException("Name should be more than 3 Characters");
        //}

        //public bool CheckCity(string city)
        //{
        //    if (Regex.IsMatch(city, "^[A-Za-z]{3,}$"))
        //        return true;
        //    throw new InvalidNameException("City should be more than 3 characters");
        //}
        //public bool CheckPassword(string password)
        //{
        //    if (Regex.IsMatch(password, "^[A-Za-z]{3,}$"))
        //        return true;
        //    throw new InvalidPasswordException("Phone number should be in (000)-000-0000");
        //}
    }
}
