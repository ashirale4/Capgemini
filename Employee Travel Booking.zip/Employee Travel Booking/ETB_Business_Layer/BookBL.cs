﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ETB_Data_Access_Layer;
using ETB_Entity_Layer;

namespace ETB_Business_Layer
{
    public class BookBL
    {
        public bool AddTicket(Book book)
        {
            try
            {
                //ValidateEmployeeInput(ticket);
                BookDL bookDL = new BookDL();
                //string empid = GenerateEmployeeID();
                //emp.EmpId = empid;
                bookDL.BookTicket(book);
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
