﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ETB_Entity_Layer;
using ETB_Data_Access_Layer;
using System.Text.RegularExpressions;
using ETB_Exception;

namespace ETB_Business_Layer
{
    public class EmployeeBL
    {
        
        public bool RemoveEmployee(Employee emp)
        {
            try
            {
                EmployeeDL employeeDL = new EmployeeDL();
                employeeDL.Delete(emp);
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool UpdateEmployee(Employee emp)
        {
            try
            {

                EmployeeDL employeeDL = new EmployeeDL();
                employeeDL.Update(emp);
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public bool AddEmployee(Employee emp)
        {
            try
            {
                //ValidateEmployeeInput(emp);
                EmployeeDL employeeDL = new EmployeeDL();
                employeeDL.Insert(emp);
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool ValidateEmployeeInput(Employee emp)
        {
            try
            {
                if (CheckName(emp.Name) && CheckCity(emp.City) && CheckPassword(emp.Password) )
                    return true;

            }
            catch (InvalidNameException ine)
            {
                throw ine;
            }
            catch (InvalidPasswordException ine)
            {
                throw ine;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return false;
        }

        public bool CheckName(string name)
        {
            if (Regex.IsMatch(name, "^[A-Za-z]{2,}$"))
                return true;
            throw new InvalidNameException("Name should be more than 2 Characters");
        }
        
        public bool CheckCity(string city)
        {
            if (Regex.IsMatch(city, "^[A-Za-z]{2,}$"))
                return true;
            throw new InvalidNameException("City should be more than 2 characters");
        }
        public bool CheckPassword(string password)
        {
            if (Regex.IsMatch(password, "^[A-Za-z]{3,}[0,9]{3,}$"))
                return true;
            throw new InvalidPasswordException("Invalid Password");
        }
    }
}
