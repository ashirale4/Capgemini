﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ETB_Entity_Layer;
using ETB_Data_Access_Layer;

namespace ETB_Business_Layer
{
    public class TravelAgentBL
    {
        public bool AddAgent(TravelAgent agent)
        {
            try
            {
                //ValidateEmployeeInput(ticket);
                TravelAgentDL travelAgentDL = new TravelAgentDL();
                //string empid = GenerateEmployeeID();
                //emp.EmpId = empid;
                travelAgentDL.Insert(agent);
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool RemoveAgent(TravelAgent agent)
        {
            try
            {
                TravelAgentDL agentDL = new TravelAgentDL();
                agentDL.Delete(agent);
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool UpdateAgent(TravelAgent agent)
        {
            try
            {
                TravelAgentDL agentDL = new TravelAgentDL();
                agentDL.Update(agent);
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        //public bool ValidateEmployeeInput(Ticket ticket)
        //{
        //    try
        //    {
        //        if (CheckName(emp.Name) && CheckCity(emp.City) && CheckPassword(emp.Password))
        //            return true;

        //    }
        //    catch (InvalidNameException ine)
        //    {
        //        throw ine;
        //    }
        //    catch (InvalidPasswordException ine)
        //    {
        //        throw ine;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    return false;
        //}

        //public bool CheckName(string name)
        //{
        //    if (Regex.IsMatch(name, "^[A-Za-z]{3,}$"))
        //        return true;
        //    throw new InvalidNameException("Name should be more than 3 Characters");
        //}

        //public bool CheckCity(string city)
        //{
        //    if (Regex.IsMatch(city, "^[A-Za-z]{3,}$"))
        //        return true;
        //    throw new InvalidNameException("City should be more than 3 characters");
        //}
        //public bool CheckPassword(string password)
        //{
        //    if (Regex.IsMatch(password, "^[A-Za-z]{3,}$"))
        //        return true;
        //    throw new InvalidPasswordException("Phone number should be in (000)-000-0000");
        //}
    }
}
