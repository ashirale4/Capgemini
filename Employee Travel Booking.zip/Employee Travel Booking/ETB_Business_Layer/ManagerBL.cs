﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ETB_Entity_Layer;
using ETB_Data_Access_Layer;

namespace ETB_Business_Layer
{
    public class ManagerBL
    {
        public bool AssignManager(Manager mng)
        {
            try
            {

                ManagerDL managerDL = new ManagerDL();
                managerDL.Assign(mng);
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool ChangeManager(Manager mng)
        {
            try
            {

                ManagerDL managerDL = new ManagerDL();
                managerDL.Change(mng);
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
