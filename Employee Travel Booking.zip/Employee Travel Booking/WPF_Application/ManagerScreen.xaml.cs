﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ETB_Entity_Layer;
using System.Data.SqlClient;
using System.Data;
using ETB_Business_Layer;

namespace WPF_Application
{
    /// <summary>
    /// Interaction logic for ManagerScreen.xaml
    /// </summary>
    public partial class ManagerScreen : Window
    {
        public ManagerScreen()
        {
            InitializeComponent();
            LoadGrid();

        }

        private void btnClear_Click(object sender, RoutedEventArgs e)
        {
            txtId.Clear();
            txtName.Clear();
            txtMid.Clear();
            cmbDesignation.SelectedIndex = -1;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MainWindow main = new MainWindow();
            main.Show();
            this.Close();
        }

        //private void btnSearch_Click(object sender, RoutedEventArgs e)
        //{
        //    int id = Convert.ToInt32(txtId.Text);
        //    Manager manager = new Manager();
        //    ManagerDL managerDl = new ManagerDL();
        //    manager.EmpId = id;
        //    SqlDataReader objDR= managerDl.Search(manager);
            
        //    txtName.Text = objDR[1].ToString();
        //    cmbDesignation.Text = objDR[3].ToString();
        //    txtMid.Text = objDR[4].ToString();
        //}
        public void LoadGrid()
        {
            SqlConnection conn = new SqlConnection(@"data source=LAPTOP-11GTHP3H\SQLEXPRESS ;initial catalog=Sprint_1;integrated security=true");
            SqlCommand cmd = new SqlCommand("select * from Employee", conn);
            DataTable dt = new DataTable();
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            dt.Load(reader);
            conn.Close();
            dgEmployees.ItemsSource = dt.DefaultView;
        }

        private void btnAssign_Click(object sender, RoutedEventArgs e)
        {
            int id = Convert.ToInt32(txtId.Text);
            int mid = Convert.ToInt32(txtMid.Text);
            string name = txtName.Text;
            string designation = cmbDesignation.Text;
          
            //

            Manager manager = new Manager();
            ManagerBL managerBL = new ManagerBL();

            manager.EmpId = id;
            manager.Mid = mid;
            manager.Name = name;
            manager.Designation = designation;
            

            managerBL.AssignManager(manager);
            MessageBox.Show(" Manager got Assigned");
            LoadGrid();
        }

        private void dgEmployees_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var data = dgEmployees.SelectedItem;
            string id = (dgEmployees.SelectedCells[0].Column.GetCellContent(data) as TextBlock).Text;
            txtId.Text = id;
            txtId.IsEnabled = false;
            string name = (dgEmployees.SelectedCells[1].Column.GetCellContent(data) as TextBlock).Text;
            txtName.Text = name;
            string mid = (dgEmployees.SelectedCells[4].Column.GetCellContent(data) as TextBlock).Text;
            txtMid.Text = mid;
            string designation = (dgEmployees.SelectedCells[3].Column.GetCellContent(data) as TextBlock).Text;
            cmbDesignation.Text = designation;
        }

        private void btnChange_Click(object sender, RoutedEventArgs e)
        {
            int id = Convert.ToInt32(txtId.Text);
            int mid = Convert.ToInt32(txtMid.Text);

            //

            Manager manager = new Manager();
            ManagerBL managerBL = new ManagerBL();

            manager.EmpId = id;
            manager.Mid = mid;


            managerBL.AssignManager(manager);
            MessageBox.Show(" Manager got Changed");
            LoadGrid();
        }
    }
}
