﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ETB_Entity_Layer;
using ETB_Business_Layer;

namespace WPF_Application
{
    /// <summary>
    /// Interaction logic for Booking.xaml
    /// </summary>
    public partial class Booking : Window
    {
        public Booking()
        {
            InitializeComponent();
            
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MainTAScreen mainTA = new MainTAScreen();
            mainTA.Show();
            this.Close();
        }
        public void LoadGrid()
        {
            SqlConnection conn = new SqlConnection(@"data source=LAPTOP-11GTHP3H\SQLEXPRESS ;initial catalog=Sprint_1;integrated security=true");
            SqlCommand cmd = new SqlCommand("select * from TravelIntenary", conn);
            DataTable dt = new DataTable();
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            dt.Load(reader);
            conn.Close();
            dgIntenary.ItemsSource = dt.DefaultView;
        }

        public void BookID()
        {
            try
            {
                SqlConnection conn = new SqlConnection(@"data source=LAPTOP-11GTHP3H\SQLEXPRESS ;initial catalog=Sprint_1;integrated security=true");

                SqlCommand cmd = new SqlCommand("Select MAX(Bid) from TravelIntenary", conn);
                conn.Open();
                var maxid = cmd.ExecuteScalar() as string;
                if (maxid == null)
                {
                    txtBook.Text = "B-000001";
                }
                else
                {
                    int intval = int.Parse(maxid.Substring(2, 6));
                    intval++;
                    txtBook.Text = String.Format("B-{0:000000}", intval);
                }
                conn.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void GetTicket()
        {
            SqlConnection objCon = new SqlConnection(@"data source=LAPTOP-11GTHP3H\SQLEXPRESS ;initial catalog=Sprint_1;integrated security=true");
            SqlCommand objCom = new SqlCommand("select * from Approve", objCon);
            objCon.Open();
            SqlDataReader objDR = objCom.ExecuteReader();
            DataTable objDT = new DataTable();
            objDT.Load(objDR);
            objCon.Close();
            cbTicket.ItemsSource = objDT.DefaultView;
            cbTicket.SelectedValuePath = objDT.Columns[1].ToString();
            cbTicket.DisplayMemberPath = objDT.Columns[0].ToString();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            LoadGrid();
            BookID();
            GetTicket();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            string bid = txtBook.Text;
            string tid = cbTicket.Text;
            string dateOfJourny = dpJourny.Text;
            double cost = Convert.ToDouble(txtCost.Text);

            Book book = new Book();
            BookBL bookBL = new BookBL();

            book.Bid = bid;
            book.Tid = tid;
            book.DateOfJourny = dateOfJourny;
            book.Cost = cost;

            bookBL.AddTicket(book);
            MessageBox.Show(" Ticket got Booked");
            LoadGrid();

            
            cbTicket.SelectedIndex = -1;
            dpJourny.SelectedDate = null;
            txtCost.Clear();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            string tid = cbTicket.Text;
            string status = "Ticket is not Available";

            Approve approve = new Approve();
            ApproveBL approveBL = new ApproveBL();

            approve.Tid = tid;
            approve.Status = status ;

            approveBL.TicketStatus(approve);
            MessageBox.Show(" Ticket got Rejected");
            LoadGrid();
            cbTicket.SelectedIndex = -1;
        }
    }
}
