﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ETB_Entity_Layer;
using ETB_Business_Layer;

namespace WPF_Application
{
    /// <summary>
    /// Interaction logic for TravelAgentScreen.xaml
    /// </summary>
    public partial class TravelAgentScreen : Window
    {
        public TravelAgentScreen()
        {
            InitializeComponent();
            LoadGrid();
            AgentID();
        }

        private void btnClear_Click(object sender, RoutedEventArgs e)
        {
            txtName.Clear();
            txtPhone.Clear();
            txtPassword.Clear();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MainWindow main = new MainWindow();
            main.Show();
            this.Close();
        }
        public void LoadGrid()
        {
            SqlConnection conn = new SqlConnection(@"data source=LAPTOP-11GTHP3H\SQLEXPRESS ;initial catalog=Sprint_1;integrated security=true");
            SqlCommand cmd = new SqlCommand("select * from TravelAgent", conn);
            DataTable dt = new DataTable();
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            dt.Load(reader);
            conn.Close();
            dgEmployees.ItemsSource = dt.DefaultView;
        }

        private void btnInsert_Click(object sender, RoutedEventArgs e)
        {
            string aid = txtId.Text;
            string name = txtName.Text;
            string phone = txtPhone.Text;
            string password = txtPassword.Text;

            TravelAgent agent = new TravelAgent();
            TravelAgentBL agentBL = new TravelAgentBL();

            agent.AgentId = aid;
            agent.AgentName = name;
            agent.Phone = phone;
            agent.Password = password;

            agentBL.AddAgent(agent);
            MessageBox.Show(" Agent got Added");
            LoadGrid();
            AgentID();

            txtName.Clear();
            txtPassword.Clear();
            txtPhone.Clear();
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            string name = txtName.Text;
            string phone = txtPhone.Text;
            string password = txtPassword.Text;

            TravelAgent agent = new TravelAgent();
            TravelAgentBL agentBL = new TravelAgentBL();

            
            agent.AgentName = name;
            agent.Phone = phone;
            agent.Password = password;
            agentBL.UpdateAgent(agent);
            MessageBox.Show(" Agent got Updated");
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            string id = txtId.Text;
            TravelAgent ta = new TravelAgent();
            TravelAgentBL taBL = new TravelAgentBL();

            ta.AgentId = id;
            taBL.RemoveAgent(ta);
            MessageBox.Show(" Agent got deleted");
            LoadGrid();
        }

        public void AgentID()
        {
            try
            {
                SqlConnection conn = new SqlConnection(@"data source=LAPTOP-11GTHP3H\SQLEXPRESS ;initial catalog=Sprint_1;integrated security=true");

                SqlCommand cmd = new SqlCommand("Select MAX(Agentid) from TravelAgent", conn);
                conn.Open();
                var maxid = cmd.ExecuteScalar() as string;
                if (maxid == null)
                {
                    txtId.Text = "A0001";
                }
                else
                {
                    int intval = int.Parse(maxid.Substring(1, 4));
                    intval++;
                    txtId.Text = String.Format("A{0:0000}", intval);
                }
                conn.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void dgEmployees_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var data = dgEmployees.SelectedItem;
            string id = (dgEmployees.SelectedCells[0].Column.GetCellContent(data) as TextBlock).Text;
            txtId.Text = id;
            txtId.IsEnabled = false;
            string name = (dgEmployees.SelectedCells[1].Column.GetCellContent(data) as TextBlock).Text;
            txtName.Text = name;
            string phone = (dgEmployees.SelectedCells[2].Column.GetCellContent(data) as TextBlock).Text;
            txtPhone.Text = phone;
            string password = (dgEmployees.SelectedCells[3].Column.GetCellContent(data) as TextBlock).Text;
            txtPassword.Text = password;
        }
    }
}
