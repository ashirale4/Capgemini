﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ETB_Entity_Layer;
using ETB_Business_Layer;

namespace WPF_Application
{
    /// <summary>
    /// Interaction logic for TicketScreen.xaml
    /// </summary>
    public partial class TicketScreen : Window
    {
        public TicketScreen()
        {
            InitializeComponent();
            TicketID();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MainEmpScreen mainEmp = new MainEmpScreen();
            mainEmp.Show();
            this.Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Flights flights = new Flights();
            flights.Show();
            this.Close();
        }

        private void btnRecord_Click(object sender, RoutedEventArgs e)
        {
            int eid = Convert.ToInt32(txtId.Text);
            string id = txtTicketId.Text;
            string source = cbSource.Text;
            string destination = cbDestination.Text;
            string flightDate = DateTime.Parse(dpFlight.Text).ToString();
            int seats = Convert.ToInt32(txtSeats.Text);

            Ticket ticket = new Ticket();
            TicketBL ticketBL = new TicketBL();

            ticket.EmpId = eid;
            ticket.Tid = id;
            ticket.Source = source;
            ticket.Destination = destination;
            ticket.FlightDate = flightDate;
            ticket.Seats = seats;

            ticketBL.AddTicket(ticket);
            MessageBox.Show(" Ticket got Raised");

            TicketID();
            txtId.Clear();
            cbSource.SelectedIndex = -1;
            cbDestination.SelectedIndex = -1;
            txtSeats.Clear();
            dpFlight.Text = null;
        }

        public void TicketID()
        {
            try
            {
                SqlConnection conn = new SqlConnection(@"data source=LAPTOP-11GTHP3H\SQLEXPRESS ;initial catalog=Sprint_1;integrated security=true");
                
                SqlCommand cmd = new SqlCommand("Select MAX(Tid) from Ticket",conn);
                conn.Open();
                var maxid = cmd.ExecuteScalar() as string;
                if (maxid == null)
                {
                    txtTicketId.Text = "T-000001";
                }
                else
                {
                    int intval = int.Parse(maxid.Substring(2, 6));
                    intval++;
                    txtTicketId.Text = String.Format("T-{0:000000}", intval);
                }
                conn.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            txtId.Clear();
            cbSource.SelectedIndex = -1;
            cbDestination.SelectedIndex = -1;
            txtSeats.Clear();
            dpFlight.Text = null;
        }
    }
}
