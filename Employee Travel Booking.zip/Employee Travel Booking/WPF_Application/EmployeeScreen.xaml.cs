﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ETB_Entity_Layer;
using ETB_Business_Layer;

namespace WPF_Application
{
    /// <summary>
    /// Interaction logic for EmployeeScreen.xaml
    /// </summary>
    public partial class EmployeeScreen : Window
    {
        public EmployeeScreen()
        {
            InitializeComponent();
            LoadGrid();
            AutoGenerate();
        }
        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            int id = Convert.ToInt32(txtId.Text);
            string name = txtName.Text;
            string department = cmbDepartment.Text;
            string designation = cmbDesignation.Text;
            string city = txtCity.Text;
            string password = txtPassword.Text;

            Employee emp =  new Employee();
            EmployeeBL empBL = new EmployeeBL();

            emp.EmpId = id;
            emp.Name = name;
            emp.Department = department;
            emp.Designation = designation;
            emp.City = city;
            emp.Password = password;

            empBL.AddEmployee(emp);
            MessageBox.Show(" Employee got Added");
            LoadGrid();
            AutoGenerate();

            txtName.Clear();
            txtCity.Clear();
            txtPassword.Clear();
            cmbDesignation.SelectedIndex = -1;
            cmbDepartment.SelectedIndex = -1;
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            int id = Convert.ToInt32(txtId.Text);
            Employee emp = new Employee();
            EmployeeBL empBL = new EmployeeBL();

            emp.EmpId = id;
            empBL.RemoveEmployee(emp);
            MessageBox.Show(" Employee got deleted");
            LoadGrid();
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            int id = Convert.ToInt32(txtId.Text);
            string name = txtName.Text;
            string department = cmbDepartment.Text;
            string designation = cmbDesignation.Text;
            string city = txtCity.Text;
            string password = txtPassword.Text;
            //

            Employee emp = new Employee();
            EmployeeBL empBL = new EmployeeBL();

            emp.EmpId = id;
            emp.Name = name;
            emp.Department = department;
            emp.Designation = designation;
            emp.City = city;
            emp.Password = password;

            empBL.UpdateEmployee(emp);
            MessageBox.Show(" Employee got Updated");
            LoadGrid();
        }
        
        
        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            MainWindow main = new MainWindow();
            main.Show();
            this.Close();
        }
       
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MainWindow main = new MainWindow();
            main.Show();
            this.Close();
        }

        private void dgEmployees_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var data = dgEmployees.SelectedItem;
            string id = (dgEmployees.SelectedCells[0].Column.GetCellContent(data) as TextBlock).Text;
            txtId.Text = id;
            txtId.IsEnabled = false;
            string name = (dgEmployees.SelectedCells[1].Column.GetCellContent(data) as TextBlock).Text;
            txtName.Text = name;
            string department = (dgEmployees.SelectedCells[2].Column.GetCellContent(data) as TextBlock).Text;
            cmbDepartment.Text = department;
            string designation = (dgEmployees.SelectedCells[3].Column.GetCellContent(data) as TextBlock).Text;
            cmbDesignation.Text = designation;
            string city = (dgEmployees.SelectedCells[5].Column.GetCellContent(data) as TextBlock).Text;
            txtCity.Text = city;
            string password = (dgEmployees.SelectedCells[6].Column.GetCellContent(data) as TextBlock).Text;
            txtPassword.Text = password;
        }

        public void LoadGrid()
        {
            SqlConnection conn = new SqlConnection(@"data source=LAPTOP-11GTHP3H\SQLEXPRESS ;initial catalog=Sprint_1;integrated security=true");
            SqlCommand cmd = new SqlCommand("select * from Employee", conn);
            DataTable dt = new DataTable();
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            dt.Load(reader);
            conn.Close();
            dgEmployees.ItemsSource = dt.DefaultView;
        }

        public void AutoGenerate()
        {
            SqlConnection con = new SqlConnection(@"data source=LAPTOP-11GTHP3H\SQLEXPRESS ;initial catalog=Sprint_1;integrated security=true");
            SqlDataAdapter adp = new SqlDataAdapter("select isnull(max(cast(empid as int)),0)+1 from Employee", con);
            DataTable dt = new DataTable();
            adp.Fill(dt);
            txtId.Text = dt.Rows[0][0].ToString();
        }

        private void btnClear_Click(object sender, RoutedEventArgs e)
        {
            txtName.Clear();
            txtCity.Clear();
            txtPassword.Clear();
            cmbDesignation.SelectedIndex = -1;
            cmbDepartment.SelectedIndex = -1;
        }
    }
}
