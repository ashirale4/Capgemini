﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ETB_Entity_Layer;
using ETB_Business_Layer;

namespace WPF_Application
{
    /// <summary>
    /// Interaction logic for ManagerCheck.xaml
    /// </summary>
    public partial class ManagerCheck : Window
    {
        public ManagerCheck()
        {
            InitializeComponent();
            LoadGrid();
            LoadGrid2();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MainMngScreen mainMng = new MainMngScreen();
            mainMng.Show();
            this.Close();
        }
        public void LoadGrid()
        {
            SqlConnection conn = new SqlConnection(@"data source=LAPTOP-11GTHP3H\SQLEXPRESS ;initial catalog=Sprint_1;integrated security=true");
            SqlCommand cmd = new SqlCommand("select * from Ticket", conn);
            DataTable dt = new DataTable();
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            dt.Load(reader);
            conn.Close();
            dgRequest.ItemsSource = dt.DefaultView;
        }

        private void btnApprove_Click(object sender, RoutedEventArgs e)
        {
            int id = Convert.ToInt32(txtId.Text);

            Approve app = new Approve();
            ApproveBL appBL = new ApproveBL();

            app.EmpId = id;

            appBL.ApproveEmployee(app);
            MessageBox.Show(" Ticket got Approved");
            LoadGrid2();
        }

        public void LoadGrid2()
        {
            SqlConnection conn = new SqlConnection(@"data source=LAPTOP-11GTHP3H\SQLEXPRESS ;initial catalog=Sprint_1;integrated security=true");
            SqlCommand cmd = new SqlCommand("select * from Approve", conn);
            DataTable dt = new DataTable();
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            dt.Load(reader);
            conn.Close();
            dgApprove.ItemsSource = dt.DefaultView;
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            int id = Convert.ToInt32(txtId.Text);
            string status = "Rejected";

            Ticket ticket = new Ticket();
            TicketBL ticketBL = new TicketBL();

            ticket.EmpId = id;
            ticket.Status = status;

            ticketBL.RejectTicket(ticket);
            MessageBox.Show(" Ticket Rejected");
            LoadGrid();
        }
    }
}
