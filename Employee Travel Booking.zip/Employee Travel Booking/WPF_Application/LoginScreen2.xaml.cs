﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WPF_Application
{
    /// <summary>
    /// Interaction logic for LoginScreen2.xaml
    /// </summary>
    public partial class LoginScreen2 : Window
    {
        public LoginScreen2()
        {
            InitializeComponent();
        }
        SqlConnection conn = new SqlConnection(@"data source=LAPTOP-11GTHP3H\SQLEXPRESS ;initial catalog=Sprint_1;integrated security=true");
        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            conn.Open();
            string login = "Select * from Employee where ENAME='" + txtUsername.Text + "' and password='" + txtPassword.Password + "'";
            SqlCommand cmd = new SqlCommand(login, conn);
            SqlDataReader reader = cmd.ExecuteReader();

            if (reader.Read() == true)
            {
                MainMngScreen mainMng = new MainMngScreen();
                mainMng.Show();
                this.Close();
            }
            else
            {
                MessageBox.Show("Invalid Username or Password ");
            }
            conn.Close();
        }

        private void btnHome_Click(object sender, RoutedEventArgs e)
        {
            ManiMain mani = new ManiMain();
            mani.Show();
            this.Close();
        }
    }
}
