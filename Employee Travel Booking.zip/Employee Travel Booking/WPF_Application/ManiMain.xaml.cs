﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WPF_Application
{
    /// <summary>
    /// Interaction logic for ManiMain.xaml
    /// </summary>
    public partial class ManiMain : Window
    {
        public ManiMain()
        {
            InitializeComponent();
        }

        private void btnAdmin_Click(object sender, RoutedEventArgs e)
        {
            LoginScreen login = new LoginScreen();
            login.Show();
            this.Close();
        }

        private void btnEmployee_Click(object sender, RoutedEventArgs e)
        {
            LoginScreen1 login = new LoginScreen1();
            login.Show();
            this.Close();
        }

        private void btnTravelAgent_Click(object sender, RoutedEventArgs e)
        {
            LoginScreen3 login = new LoginScreen3();
            login.Show();
            this.Close();
        }

        private void btnManager_Click(object sender, RoutedEventArgs e)
        {
            LoginScreen2 login = new LoginScreen2();
            login.Show();
            this.Close();
        }
    }
}
