﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ETB_Business_Layer;
using ETB_Entity_Layer;

namespace WPF_Application
{
    /// <summary>
    /// Interaction logic for MainEmpScreen.xaml
    /// </summary>
    public partial class MainEmpScreen : Window
    {
        public MainEmpScreen()
        {
            InitializeComponent();
            LoadGrid();
            LoadGrid2();
            LoadGrid3();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            TicketScreen ticket = new TicketScreen();
            ticket.Show();
            this.Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            ManiMain mani = new ManiMain();  
            mani.Show();
            this.Close();
        }

        public void LoadGrid()
        {
            SqlConnection conn = new SqlConnection(@"data source=LAPTOP-11GTHP3H\SQLEXPRESS ;initial catalog=Sprint_1;integrated security=true");
            SqlCommand cmd = new SqlCommand("select * from Ticket", conn);
            DataTable dt = new DataTable();
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            dt.Load(reader);
            conn.Close();
            dgRaise.ItemsSource = dt.DefaultView;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            EmployeeBL employeeBL = new EmployeeBL();

        }

        public void LoadGrid2()
        {
            SqlConnection conn = new SqlConnection(@"data source=LAPTOP-11GTHP3H\SQLEXPRESS ;initial catalog=Sprint_1;integrated security=true");
            SqlCommand cmd = new SqlCommand("select * from Approve", conn);
            DataTable dt = new DataTable();
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            dt.Load(reader);
            conn.Close();
            dgApprove.ItemsSource = dt.DefaultView;
        }

        public void LoadGrid3()
        {
            SqlConnection conn = new SqlConnection(@"data source=LAPTOP-11GTHP3H\SQLEXPRESS ;initial catalog=Sprint_1;integrated security=true");
            SqlCommand cmd = new SqlCommand("select * from TravelIntenary", conn);
            DataTable dt = new DataTable();
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            dt.Load(reader);
            conn.Close();
            dgBook.ItemsSource = dt.DefaultView;
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            int id = Convert.ToInt32(txtId.Text);

            Ticket ticket = new Ticket();
            TicketBL ticketBL = new TicketBL();

            ticket.EmpId = id;

            ticketBL.CancelTicket(ticket);
            MessageBox.Show(" Ticket Cancelled");
            LoadGrid();
        }
    }
}
