﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WPF_Application
{
    /// <summary>
    /// Interaction logic for Flights.xaml
    /// </summary>
    public partial class Flights : Window
    {
        public Flights()
        {
            InitializeComponent();
            LoadGrid();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            TicketScreen ticket = new TicketScreen();
            ticket.Show();
            this.Close();
        }

        public void LoadGrid()
        {
            SqlConnection conn = new SqlConnection(@"data source=LAPTOP-11GTHP3H\SQLEXPRESS ;initial catalog=Sprint_1;integrated security=true");
            SqlCommand cmd = new SqlCommand("select * from TravelIntenary", conn);
            DataTable dt = new DataTable();
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            dt.Load(reader);
            conn.Close();
            dgFlight.ItemsSource = dt.DefaultView;
        }
    }
}
